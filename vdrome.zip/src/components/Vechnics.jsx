import React from 'react';
import playerBg from '../assets/image/vechnics/player-background.png';

export default function Vechnics() {
  return (
    <div
      className="aspect-[1154/898] w-[43.32%] bg-no-repeat bg-contain bg-bottom"
      style={{ backgroundImage: `url(${playerBg})` }}
    />
  );
}